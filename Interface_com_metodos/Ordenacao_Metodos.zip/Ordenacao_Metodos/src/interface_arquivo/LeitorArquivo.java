/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package interface_arquivo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author gspal
 */
public class LeitorArquivo {

    public List<Integer> lerArquivo(String caminho){
        
        List<Integer> listaNumeros = new ArrayList<>();
        Integer numero;
        int linhaErrada = 0;
        Integer numeroLinhas = 0;
        
        try (BufferedReader br = new BufferedReader(new FileReader(caminho))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                
                try{
                    
                    numero = Integer.valueOf(linha);
                    numeroLinhas++;
                    
                } catch(NumberFormatException i){
                    
                    linhaErrada++;
                    numero = null;
                    
                }
                
                if (numero != null){
                    listaNumeros.add(numero);
                }
                
            }
            
            listaNumeros.add(numeroLinhas);
            
            System.out.println("Numero de linhas que foram desconsideradas: " + linhaErrada);
            
            return listaNumeros;
            
        } catch (IOException e) {
            
            System.out.println("Erro ao ler o arquivo: " + e.getMessage());
            
            return null;
            
        }
    
    }
        
}
