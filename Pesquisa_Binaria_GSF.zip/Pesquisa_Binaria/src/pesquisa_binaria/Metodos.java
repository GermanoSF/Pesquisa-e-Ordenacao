/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pesquisa_binaria;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author laboratorio
 */
public class Metodos {
    
    public static int esta(List<Integer> lista, int numero){
        
        if (lista.get(lista.size()/2) > numero && lista.size()>=2){
            
            return 0 + esta(lista.subList(0,lista.size()/2),numero);
            
        }
        
        if (lista.get(lista.size()/2) < numero && lista.size()>=2){
            
            return 0 + esta(lista.subList((lista.size()/2)+1,lista.size()), numero);
            
        }
        
        if (lista.get(lista.size()/2) == numero){
            
            return 1;
            
        }
        
        return 0;
        
    }
    
}
