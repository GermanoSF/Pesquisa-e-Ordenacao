/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pesquisa_binaria;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author laboratorio
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        List<Integer> lista= new ArrayList<>();
        
        for (int i=0; i<=200; i+=5){
            
            lista.add(i);
            
        }
        
        System.out.println(lista);
        
        if (Metodos.esta(lista, 3) == 1){
            
            System.out.println("Esta na lista");
            
        }
        else{
            
            System.out.println("Nao esta na lista");
            
        }
        
    }
    
}
