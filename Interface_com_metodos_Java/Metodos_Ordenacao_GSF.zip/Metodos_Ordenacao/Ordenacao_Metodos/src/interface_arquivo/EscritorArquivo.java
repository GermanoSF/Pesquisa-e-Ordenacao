/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interface_arquivo;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

/**
 *
 * @author gspal
 */
public class EscritorArquivo {
    
    public void escrever(String caminho, List<Integer> lista){
        
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(caminho))) {
            
            for (Integer i : lista){
                
                bw.write(String.valueOf(i));
                bw.newLine();
            
            }
            
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }
    
}
