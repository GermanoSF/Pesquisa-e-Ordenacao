/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interface_arquivo;

/**
 *
 * @author gspal
 */
public class DadosTabela {
    
    private String metodo;
    private Long comparacoes;
    private Long trocas;
    private double tempo;

    public DadosTabela(String metodo, Long comparacoes, Long trocas, double tempo) {
        this.metodo = metodo;
        this.comparacoes = comparacoes;
        this.trocas = trocas;
        this.tempo = tempo;
    }
    
    public String getMetodo() {
        return metodo;
    }

    public Long getComparacoes() {
        return comparacoes;
    }

    public Long getTrocas() {
        return trocas;
    }

    public double getTempo() {
        return tempo;
    }    
    
}
