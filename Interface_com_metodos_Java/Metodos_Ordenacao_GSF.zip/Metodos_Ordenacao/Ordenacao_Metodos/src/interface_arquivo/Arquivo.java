/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interface_arquivo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFileChooser;

/**
 *
 * @author laboratorio
 */
public class Arquivo {
    
    public static void escrever(String caminho, List<Integer> lista){
        
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(caminho))) {
            
            for (Integer i : lista){
                
                bw.write(String.valueOf(i));
                bw.newLine();
            
            }
            
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }
    
    public List<Integer> lerArquivo(String caminho){
        
        List<Integer> listaNumeros = new ArrayList<>();
        Integer numero;
        int linhaErrada = 0;
        Integer numeroLinhas = 0;
        
        try (BufferedReader br = new BufferedReader(new FileReader(caminho))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                
                try{
                    
                    numero = Integer.valueOf(linha);
                    numeroLinhas++;
                    
                } catch(NumberFormatException i){
                    
                    linhaErrada++;
                    numero = null;
                    
                }
                
                if (numero != null){
                    listaNumeros.add(numero);
                }
                
            }
            
            listaNumeros.add(numeroLinhas);
            
            System.out.println("Numero de linhas que foram desconsideradas: " + linhaErrada);
            
            return listaNumeros;
            
        } catch (IOException e) {
            
            System.out.println("Erro ao ler o arquivo: " + e.getMessage());
            
            return null;
            
        }
    
    }
    
    public String selecionarArquivo() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Selecione um arquivo");

        int resultado = fileChooser.showOpenDialog(null);

        if (resultado == JFileChooser.APPROVE_OPTION) {
            // Pega o caminho completo como String
            return fileChooser.getSelectedFile().getAbsolutePath();
        }

        return null; // caso o usuário cancele
    }
    
}
