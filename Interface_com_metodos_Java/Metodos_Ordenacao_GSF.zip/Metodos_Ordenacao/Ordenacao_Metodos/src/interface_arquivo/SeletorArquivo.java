/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interface_arquivo;

import javax.swing.JFileChooser;

/**
 *
 * @author gspal
 */
public class SeletorArquivo {
    
    public String selecionarArquivo() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Selecione um arquivo");

        int resultado = fileChooser.showOpenDialog(null);

        if (resultado == JFileChooser.APPROVE_OPTION) {
            // Pega o caminho completo como String
            return fileChooser.getSelectedFile().getAbsolutePath();
        }

        return null; // caso o usuário cancele
    }
    
}
