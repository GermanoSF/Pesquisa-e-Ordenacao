/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package metodos_ordenacao;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author gspal
 */
public class Ordenacao {
    
    private static Long comparacoes;
    private static Long trocas;
    
    List<Long> listaCT = new ArrayList<>();
    
    public List<Integer> bolha(List<Integer> list) {
        
        List<Integer> lista = new ArrayList<>(list);
        
        boolean houveTroca = true;
        comparacoes = 0L;
        trocas = 0L;

        // Algoritmo de ordenação Bolha
        while (houveTroca) {
            houveTroca = false;
            for (int i = 0; i < lista.size() - 1; i++) {
                comparacoes++;
                if (lista.get(i) > lista.get(i + 1)) {
                    trocas++;
                    houveTroca = true;

                    // Troca dos elementos
                    int tmp = lista.get(i);
                    lista.set(i, lista.get(i + 1));
                    lista.set(i + 1, tmp);
                }
            }
        }

        return lista;
    }
    
    public List<Integer> insercao(List<Integer> list) {
        
        List<Integer> numeros = new ArrayList<>(list);
        
        int n = numeros.size();
        comparacoes = 0L;
        trocas = 0L;

        for (int i = 1; i < n; i++) {
            int tmp = numeros.get(i);
            int j = i - 1;

            while (j >= 0 && tmp < numeros.get(j)) {
                comparacoes++;
                numeros.set(j + 1, numeros.get(j));
                trocas++;
                j--;
            }

            if (j >= 0) {
                comparacoes++;
            }

            numeros.set(j + 1, tmp);
        }

        return numeros;
    }
    
    public List<Integer> pente(List<Integer> list) {
        
        List<Integer> lista = new ArrayList<>(list);
        
        int distancia = lista.size();
        boolean houveTroca = true;
        comparacoes = 0L;
        trocas = 0L;

        while (houveTroca || distancia > 1) {
            distancia = (int)(distancia / 1.3);
            if (distancia < 1) {
                distancia = 1;
            }
            houveTroca = false;

            for (int i = 0; i < lista.size() - distancia; i++) {
                comparacoes++;
                if (lista.get(i) > lista.get(i + distancia)) {
                    trocas++;
                    houveTroca = true;

                    // troca
                    int tmp = lista.get(i);
                    lista.set(i, lista.get(i + distancia));
                    lista.set(i + distancia, tmp);
                }
            }
        }

        return lista;
    }

    // Método de particionamento
    private int particiona(List<Integer> lista, int ini, int fim) {
        int pivo = lista.get(fim);
        int i = ini - 1;

        for (int j = ini; j < fim; j++) {
            comparacoes++;
            if (lista.get(j) <= pivo) {
                i++;
                // troca vetor[i] com vetor[j]
                int temp = lista.get(i);
                lista.set(i, lista.get(j));
                lista.set(j, temp);
                trocas++;
            }
        }

        // coloca o pivô na posição correta
        int temp = lista.get(i + 1);
        lista.set(i + 1, lista.get(fim));
        lista.set(fim, temp);
        trocas++;

        return i + 1;
    }

    // Método principal do QuickSort
    private void quickSort(List<Integer> lista, int ini, int fim) {
        if (ini < fim) {
            int pivo = particiona(lista, ini, fim);
            quickSort(lista, ini, pivo - 1);
            quickSort(lista, pivo + 1, fim);
        }
    }

    // Método que o usuário chama
    public List<Integer> quickSort(List<Integer> list) {
        comparacoes = 0L;
        trocas = 0L;
        
        List<Integer> lista = new ArrayList<>(list);

        quickSort(lista, 0, lista.size() - 1);

        // adiciona comparações e trocas no final da própria lista
        
        return lista;
    }
    
    public List<Long> comparacoesTrocas(){
       
        listaCT.clear();
        listaCT.add(comparacoes);
        listaCT.add(trocas);
        
        return listaCT;
        
    }
    
}
