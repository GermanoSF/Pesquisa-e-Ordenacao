/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pesquisa;

/**
 *
 * @author laboratorio
 */
public class ManipulacaoString {
    
    private StringBuffer sb1 = new StringBuffer();
    
    private void limpar(){
        
        sb1.setLength(0);
        
    }
    
    public String removerUltimo(String st){
        
        limpar();
        
        sb1.append(st);
        
        if (sb1.length()>0){
            
            sb1.setLength(sb1.length()-1);
            
        }
        
        return sb1.toString();
        
    }
    
    public String splitporE(String frase,int contador){
        
        if (frase.length()==0) return "0"; 
        
        for (int i = 0;i < frase.length()-1;i++){
            
            if (frase.charAt(i)==' '){
                
                contador++;
                
            }
            
        }
        
        return String.valueOf(contador+1);
        
    }
    
}
