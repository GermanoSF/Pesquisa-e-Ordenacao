/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pesquisaordenacao;

/**
 *
 * @author laboratorio
 */
public class PesquisaOrdenacao {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Filhos filhos = new Filhos();
        
        String pai = "0000111111";
        String mae = "111100000";
        
        String filhosJuntos = filhos.calcular(pai,mae);
        
        System.out.println(filhosJuntos);
        
    }
    
}
