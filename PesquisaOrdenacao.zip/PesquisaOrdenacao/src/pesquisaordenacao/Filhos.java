/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pesquisaordenacao;

/**
 *
 * @author laboratorio
 */
public class Filhos {
    
    private StringBuffer filhos = new StringBuffer();
    
    private StringBuffer pai = new StringBuffer();
    private StringBuffer mae = new StringBuffer();
    
    private int tamanhoMetade;
    
    public String calcular(String pai, String mae){
        
        filhos.setLength(0);
        
        appends(pai,mae);
        
        tamanhoMetade = (this.pai.length()/2)-1;
        
        this.pai.setLength(tamanhoMetade);
        this.mae.delete(0, tamanhoMetade);
        
        filhos.append(this.pai.toString());
        filhos.append(this.mae.toString());
        
        filhos.append(" ");
        
        appends(pai,mae);
        
        this.mae.setLength(tamanhoMetade);
        this.pai.delete(0, tamanhoMetade);
        
        filhos.append(this.mae.toString());
        filhos.append(this.pai.toString());
        
        return filhos.toString();
        
    }
    
    public void appends(String pai,String mae){
        
        this.pai.setLength(0);
        this.mae.setLength(0);
        
        this.pai.append(pai);
        this.mae.append(mae);
        
    }
    
}
