/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arquivotxt;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

/**
 *
 * @author gspal
 */
public class Util {
    
    public static List<Double> dados(List<Double> linhas,String caminho) {
        
     try (BufferedReader br = new BufferedReader(new FileReader(caminho))) {
         String linha;
         while ((linha = br.readLine()) != null) {
             linhas.add(Double.parseDouble(linha));
         }
         
         return linhas;
         
     } 
     catch (IOException e) {
         e.printStackTrace();
     }
     
     return linhas;
     
    }
    
}
