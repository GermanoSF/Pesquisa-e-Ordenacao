/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arquivotxt;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author gspal
 */
public class Main {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        List<Double> linhas = new ArrayList<>();
        
        System.out.print("Caminho do arquivo: ");
        String caminho = sc.nextLine();
        linhas = Util.dados(linhas, caminho);
        System.out.println("\nConteudo do arquivo:\n");
        
        for (Double linha : linhas){
            
            System.out.println(linha);
            
        }
        sc.close();
        
    }
    
}
