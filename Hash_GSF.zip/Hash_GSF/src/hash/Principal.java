package hash;

import java.util.ArrayList;
import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        // Cria um vetor (array) de 10 posições, cada uma será uma lista
        ArrayList<Integer>[] tabela = new ArrayList[10];

        // Inicializa cada posição do vetor com uma nova lista
        for (int i = 0; i < tabela.length; i++) {
            tabela[i] = new ArrayList<>();
        }

        Scanner teclado = new Scanner(System.in);
        int numero, endereco;

        // Lê 5 números fornecidos pelo usuário
        for (int i = 0; i < 5; i++) {
            System.out.print("Numero: ");
            numero = teclado.nextInt();

            // Calcula o endereço do número dentro da tabela para o espalhamento
            endereco = Util.hash(numero, tabela.length);
            
            if (!tabela[endereco].contains(numero)){
                
                System.out.println("Endereco gerado: " + endereco);
                // Insere o número no endereço gerado
                tabela[endereco].add(numero);
            }
            else{
                
                System.out.println("O numero digitado ja existe no hash!");
                
            }
            
        }
        
        int posicao =0;
        for (ArrayList<Integer> lItem : tabela){
            
            System.out.print("Posicao "+posicao+", numeros por posicao: ");
            posicao++;
            for (int i = 0; i < lItem.size(); i++){
                
                System.out.print(String.valueOf(lItem.get(i))+" ");
                
            }
            
            System.out.println("");
            
        }

        System.out.println("Numero a ser buscado: ");
        System.out.println(Util.busca(teclado.nextInt(),tabela));
        System.out.println("Numero para deletar: ");
        System.out.println(Util.deletar(teclado.nextInt(),tabela));
        
        posicao =0;
        for (ArrayList<Integer> lItem : tabela){
            
            System.out.print("Posicao "+posicao+", numeros por posicao: ");
            posicao++;
            for (int i = 0; i < lItem.size(); i++){
                
                System.out.print(String.valueOf(lItem.get(i))+" ");
                
            }
            
            System.out.println("");
            
        }
        
        teclado.close();

    }
}