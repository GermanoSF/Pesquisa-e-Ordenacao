/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hash;

import java.util.ArrayList;

/**
 *
 * @author laboratorio
 */
public class Util {
    
    public static int hash(int numero,int tabelaL){
        
        return numero % tabelaL;
        
    }
    
    public static String busca(int numero,ArrayList<Integer>[] tabela){
        
        if (tabela[numero%tabela.length].contains(numero)){
            
            return "Posicao no hash: " + String.valueOf(numero%tabela.length);
            
        }
        
        return "Numero nao encontrado";
        
    }
    
    public static String deletar(int numero,ArrayList<Integer>[] tabela){
        
        if (tabela[numero%tabela.length].contains(numero)){
            
            tabela[numero%tabela.length].remove(Integer.valueOf(numero));
            return "Numero " + String.valueOf(numero) + " deletado!";
            
        }
        
        return "Numero nao encontrado";
        
    }
    
}
